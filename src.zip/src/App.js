import logo from './logo.svg';
import './App.css';
import Login from './screens/Login';
import SU1 from './screens/register_component_1';
import QuickSightView from './screens/QuickSightView';

function App() {
  return (
    <div>
      
    <Login/>
    {/* <SU1/> */}
    {/* <QuickSightView/> */}
    </div>
  );
}

export default App;
